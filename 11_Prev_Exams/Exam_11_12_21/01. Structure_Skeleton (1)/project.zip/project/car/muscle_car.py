from project.car.car import Car


class MuscleCar(Car):
    def __init__(self, model: str, speed_limit: int):
        self.model = model
        self.min_speed_limit = 250
        self.max_speed_limit = 450
        self.speed_limit = speed_limit
        self.is_taken = False


